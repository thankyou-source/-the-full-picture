# The Full Picture

**Every source. One story.**

Zero-cost prototype for grouping fragmented public reporting into real-world events and exposing the source trail.

Initial topic: UK Migration.

Evidence labels:
- Officially confirmed
- Multiple independent sources
- Single-source report
- Unverified

The core rule is that multiple copies of one originating claim do not become multiple independent sources.
